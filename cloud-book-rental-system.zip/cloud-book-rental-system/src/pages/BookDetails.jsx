import { useState } from "react";

function BookDetails() {
  const [rented, setRented] = useState(false);

  const book = {
    title: "The Alchemist",
    author: "Paulo Coelho",
    category: "Fiction",
    price: "₹30",
    duration: "7 Days",
    rating: "4.8",
    icon: "📕",
    description:
      "The Alchemist is a popular inspirational novel about following your dreams and discovering your personal journey. It follows a young shepherd who travels in search of a treasure and learns important lessons about life, courage and purpose.",
  };

  return (
    <div className="details-page">
      <div className="details-container">

        <button
          className="back-btn"
          onClick={() => (window.location.href = "/books")}
        >
          ← Back to Books
        </button>

        <div className="details-card">

          <div className="details-cover">
            <span>{book.icon}</span>
          </div>

          <div className="details-info">

            <span className="details-category">
              {book.category}
            </span>

            <h1>{book.title}</h1>

            <p className="details-author">
              Written by <strong>{book.author}</strong>
            </p>

            <div className="rating">
              ⭐ {book.rating} / 5
            </div>

            <p className="details-description">
              {book.description}
            </p>

            <div className="rental-info">

              <div>
                <span>Rental Price</span>
                <strong>{book.price}</strong>
              </div>

              <div>
                <span>Rental Period</span>
                <strong>{book.duration}</strong>
              </div>

              <div>
                <span>Availability</span>
                <strong className="available">
                  Available
                </strong>
              </div>

            </div>

            {!rented ? (
              <button
                className="rent-large-btn"
                onClick={() => setRented(true)}
              >
                📚 Rent This Book
              </button>
            ) : (
              <div className="rental-success">
                <div>✅</div>

                <h3>Book Rented Successfully!</h3>

                <p>
                  You have rented "{book.title}" for{" "}
                  {book.duration}.
                </p>

                <button
                  onClick={() =>
                    (window.location.href = "/")
                  }
                >
                  Go to Home
                </button>
              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  );
}

export default BookDetails;