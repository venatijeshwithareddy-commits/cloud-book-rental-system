import { useState } from "react";

function Books() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");

  const books = [
    {
      id: 1,
      title: "The Alchemist",
      author: "Paulo Coelho",
      category: "Fiction",
      price: "₹30",
      icon: "📕",
    },
    {
      id: 2,
      title: "Atomic Habits",
      author: "James Clear",
      category: "Self Help",
      price: "₹40",
      icon: "📘",
    },
    {
      id: 3,
      title: "Rich Dad Poor Dad",
      author: "Robert Kiyosaki",
      category: "Finance",
      price: "₹35",
      icon: "📗",
    },
    {
      id: 4,
      title: "The Psychology of Money",
      author: "Morgan Housel",
      category: "Finance",
      price: "₹45",
      icon: "📙",
    },
    {
      id: 5,
      title: "Ikigai",
      author: "Héctor García",
      category: "Self Help",
      price: "₹35",
      icon: "📔",
    },
    {
      id: 6,
      title: "The Hobbit",
      author: "J.R.R. Tolkien",
      category: "Fiction",
      price: "₹40",
      icon: "📚",
    },
    {
      id: 7,
      title: "A Brief History of Time",
      author: "Stephen Hawking",
      category: "Science",
      price: "₹50",
      icon: "🔬",
    },
    {
      id: 8,
      title: "The 7 Habits",
      author: "Stephen Covey",
      category: "Self Help",
      price: "₹40",
      icon: "📓",
    },
  ];

  const filteredBooks = books.filter((book) => {
    const matchesSearch =
      book.title.toLowerCase().includes(search.toLowerCase()) ||
      book.author.toLowerCase().includes(search.toLowerCase());

    const matchesCategory =
      category === "All" || book.category === category;

    return matchesSearch && matchesCategory;
  });

  return (
    <div className="books-page">
      {/* Page Header */}
      <section className="books-header">
        <p className="section-label">OUR COLLECTION</p>

        <h1>Explore Our Books</h1>

        <p>
          Find your next favorite book from our growing collection.
          Search, filter and rent books easily.
        </p>
      </section>

      {/* Search and Filter */}
      <section className="book-controls">
        <div className="search-box">
          🔍
          <input
            type="text"
            placeholder="Search by title or author..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="category-buttons">
          {["All", "Fiction", "Finance", "Self Help", "Science"].map(
            (item) => (
              <button
                key={item}
                className={category === item ? "active-category" : ""}
                onClick={() => setCategory(item)}
              >
                {item}
              </button>
            )
          )}
        </div>
      </section>

      {/* Results */}
      <section className="all-books">
        <div className="results-header">
          <h2>Available Books</h2>

          <span>{filteredBooks.length} books found</span>
        </div>

        {filteredBooks.length > 0 ? (
          <div className="all-books-grid">
            {filteredBooks.map((book) => (
              <div className="book-card" key={book.id}>
                <div className="book-cover">
                  <span>{book.icon}</span>
                </div>

                <div className="book-info">
                  <span className="category">{book.category}</span>

                  <h3>{book.title}</h3>

                  <p className="author">by {book.author}</p>

                  <div className="book-bottom">
                    <span className="price">
                      {book.price} / 7 days
                    </span>

                    <button className="rent-btn">
                      Rent Now
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="no-books">
            <div>📚</div>
            <h3>No books found</h3>
            <p>Try a different search or category.</p>
          </div>
        )}
      </section>
    </div>
  );
}

export default Books;