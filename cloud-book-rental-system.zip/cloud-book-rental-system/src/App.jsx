import "./index.css";
import Books from "./pages/Books";
import BookDetails from "./pages/BookDetails";

function App() {
  const path = window.location.pathname;

  if (path === "/books") {
    return <Books />;
  }

  if (path === "/book-details") {
    return <BookDetails />;
  }

  const books = [
    {
      id: 1,
      title: "The Alchemist",
      author: "Paulo Coelho",
      category: "Fiction",
      price: "₹30 / 7 days",
      emoji: "📕",
    },
    {
      id: 2,
      title: "Atomic Habits",
      author: "James Clear",
      category: "Self Help",
      price: "₹40 / 7 days",
      emoji: "📘",
    },
    {
      id: 3,
      title: "Rich Dad Poor Dad",
      author: "Robert Kiyosaki",
      category: "Finance",
      price: "₹35 / 7 days",
      emoji: "📗",
    },
    {
      id: 4,
      title: "The Psychology of Money",
      author: "Morgan Housel",
      category: "Finance",
      price: "₹45 / 7 days",
      emoji: "📙",
    },
  ];

  return (
    <div className="app">
      {/* Navigation Bar */}
      <nav className="navbar">
        <div className="logo">
          📚 <span>CloudBook</span>
        </div>

        <div className="nav-links">
          <a href="#home">Home</a>
          <a href="#books">Books</a>
          <a href="#categories">Categories</a>
          <a href="#about">About</a>
        </div>

        <div className="nav-buttons">
          <button className="login-btn">Login</button>
          <button className="register-btn">Register</button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="hero" id="home">
        <div className="hero-content">
          <p className="small-title">WELCOME TO CLOUDBOOK</p>

          <h1>
            Your Next Great
            <br />
            <span>Book Awaits.</span>
          </h1>

          <p className="hero-text">
            Discover, rent and enjoy your favorite books from anywhere.
            Build your personal reading journey with CloudBook.
          </p>

          <div className="hero-buttons">
           <button
             className="primary-btn"
             onClick={() => (window.location.href = "/books")}
>
             Browse Books →
           </button>
            <button className="secondary-btn">Learn More</button>
          </div>
        </div>

        <div className="hero-book">
          <div className="book-stack">
            <div className="large-book">📖</div>
            <div className="floating-book">📚</div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="features">
        <div className="feature">
          <div className="feature-icon">📚</div>
          <div>
            <h3>Wide Collection</h3>
            <p>Thousands of books to explore.</p>
          </div>
        </div>

        <div className="feature">
          <div className="feature-icon">☁️</div>
          <div>
            <h3>Cloud Access</h3>
            <p>Access your rentals anywhere.</p>
          </div>
        </div>

        <div className="feature">
          <div className="feature-icon">⚡</div>
          <div>
            <h3>Easy Rental</h3>
            <p>Rent your favorite books quickly.</p>
          </div>
        </div>
      </section>

      {/* Books Section */}
      <section className="books-section" id="books">
        <div className="section-heading">
          <div>
            <p className="section-label">EXPLORE</p>
            <h2>Popular Books</h2>
          </div>

          <button className="view-all-btn">View All Books →</button>
        </div>

        <div className="book-grid">
          {books.map((book) => (
            <div className="book-card" key={book.id}>
              <div className="book-cover">
                <span>{book.emoji}</span>
              </div>

              <div className="book-info">
                <span className="category">{book.category}</span>

                <h3>{book.title}</h3>

                <p className="author">by {book.author}</p>

                <div className="book-bottom">
                  <span className="price">{book.price}</span>
                  <button className="rent-btn">Rent</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="categories" id="categories">
        <p className="section-label">DISCOVER</p>
        <h2>Browse by Category</h2>

        <div className="category-grid">
          <div className="category-card">
            <span>📖</span>
            <h3>Fiction</h3>
            <p>120+ Books</p>
          </div>

          <div className="category-card">
            <span>💰</span>
            <h3>Finance</h3>
            <p>80+ Books</p>
          </div>

          <div className="category-card">
            <span>🧠</span>
            <h3>Self Help</h3>
            <p>95+ Books</p>
          </div>

          <div className="category-card">
            <span>🔬</span>
            <h3>Science</h3>
            <p>70+ Books</p>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="about" id="about">
        <div>
          <p className="section-label">ABOUT CLOUDBOOK</p>
          <h2>Reading made simple.</h2>
        </div>

        <p>
          CloudBook is a book rental management platform designed to make
          discovering and renting books simple, convenient and accessible.
          Find your favorite books and enjoy a better reading experience.
        </p>
      </section>

      {/* Footer */}
      <footer>
        <div className="footer-logo">📚 CloudBook</div>

        <p>© 2026 CloudBook. Book Rental Management System.</p>

        <div className="footer-links">
          <a href="#home">Home</a>
          <a href="/books">Books</a>
          <a href="#about">About</a>
        </div>
      </footer>
    </div>
  );
}

export default App;